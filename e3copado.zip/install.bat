cd %USERPROFILE%\e3copado\
start bat1.bat
cd %USERPROFILE%\e3copado\
start bat2.bat
cd %USERPROFILE%\e3copado\
start bat3.bat
cd %USERPROFILE%\e3copado\
start bat4.bat