cd %USERPROFILE%

type nul > .npmrc
echo registry=https://humana.jfrog.io/artifactory/api/npm/e3-copado-npm-virtual/ >> .npmrc
echo email=e3-copao-svc-acct@none.com >> .npmrc
echo always-auth=true >> .npmrc
echo strict-ssl=false >> .npmrc
echo //humana.jfrog.io/artifactory/api/npm/e3-copado-npm-virtual/:_authToken=cmVmdGtuOjAxOjE3MjA3MjMwMzk6cVk1UzA5ZG8xVDV0Z1dCcE5pOE1iOVBBbjNV >> .npmrc


cd %USERPROFILE%\AppData\Local\sfdx

type nul > unsignedPluginAllowList.json
echo [ >> unsignedPluginAllowList.json
echo     "@copado/copado-cli" >> unsignedPluginAllowList.json
echo ] >> unsignedPluginAllowList.json

TIMEOUT /T 10
cd %USERPROFILE%
mkdir copado
cd copado
npm pack @copado/copado-cli



