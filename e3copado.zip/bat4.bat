cd %USERPROFILE%

sfdx update

TIMEOUT /T 10

echo "Copado-Cli 2.0.1 Installation is successful - Try running "sfdx plugins" command to verify" 