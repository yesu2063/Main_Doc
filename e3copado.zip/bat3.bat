cd "%USERPROFILE%\copado\copado-cli"


npm install

cd "%USERPROFILE%"

npm install sfdx-cli –global

SET sfdx="%USERPROFILE%\AppData\Roaming\npm"

TIMEOUT /T 10
