mkdir %USERPROFILE%\copado\cli
tar --extract --file %USERPROFILE%\copado\copado-copado-cli-2.0.1.tgz --directory %USERPROFILE%\copado\cli


move %USERPROFILE%\copado\cli\package %USERPROFILE%\copado\copado-cli
cd %USERPROFILE%\copado\copado-cli
sfdx plugins:link copado-cli
TIMEOUT /T 10

cmd /k
TIMEOUT /T 10
